# Zanocuj: kompas do błądzenia bez mapy

Aplikacja na Androida (Kotlin + Jetpack Compose). Czarny ekran, trzy pierścienie,
strzałki do najbliższych obszarów programu "Zanocuj w lesie". Wszystko offline,
zero API, zero kluczy, zero Google Play Services.

## Budowanie

Potrzebny Android Studio (Ladybug lub nowszy) albo samo Android SDK + JDK 17.

```bash
# w katalogu projektu (wrapper jest w paczce)
chmod +x gradlew   # zip gubi bit wykonywalny
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Albo: File > Open w Android Studio, potem Run. Wersja release (`assembleRelease`)
ma włączony R8, ale nie jest podpisana.

Wersje: AGP 8.5.0, Kotlin 1.9.24, Compose BOM 2024.06.00, minSdk 26, targetSdk 34.

## Ekran

- Trzy pierścienie: 0-30 km, 30-60 km, 60-90 km. Odległość mapuje się liniowo na promień,
  więc pozycja strzałki w obrębie pierścienia to realna odległość, a nie tylko przynależność do zakresu.
- Strzałka wskazuje kierunek do **najbliższej krawędzi** obszaru (a nie do jego środka).
- Wielkość strzałki: pierwiastek z powierzchni, znormalizowany do zakresu obszarów aktualnie
  widocznych na ekranie. Skala jest względna, nie sztywna.
- Kolor: gradient czerwony (najmniejszy widoczny obszar) do zielonego (największy widoczny).
- Cyjan: obszar przylegający do dużej wody (szczegóły niżej). Kolor jest unikalny i nadpisuje gradient.
  Zmiana na żółty: `COL_WATER` w `Radar.kt`.
- Podpis: dwa wiersze, odległość i hektary, 9sp. Podpisy nie nachodzą na siebie ani na groty;
  jeśli podpis musi wejść na linię pierścienia, tło pod tekstem wygasza linię, a cienka kreska
  łączy podpis ze strzałką. Jeśli mimo wszystko nie ma miejsca, znika sam podpis, nigdy strzałka.
- Środkowa tarcza pojawia się tylko gdy ustawisz cel: strzałka i odległość do wybranego waypointa.
- Kwadracik w lewym dolnym rogu to mapa. Dotknięcie rozwija ją na pełny ekran:
  przeciąganie przesuwa, szczypanie skaluje, dotknięcie ustawia cel, przytrzymanie kasuje cel.
  Mapa jest wektorowa i rysowana z tego samego pliku co strzałki, więc działa bez internetu.
- Napis w prawym górnym rogu przełącza "kompas" (ekran obraca się z telefonem) i "północ"
  (góra ekranu to zawsze północ geograficzna). W trybie "północ" czujnik obrotu jest wyrejestrowany.
- Deklinacja magnetyczna liczona z `GeomagneticField`, więc strzałki celują w północ geograficzną.

## Zużycie energii

- Brak serwisu w tle, brak wakelocków, brak budzenia. Aplikacja zbiera dane tylko gdy jest na wierzchu.
- Lokalizacja: `LocationManager` (FUSED na API 31+, inaczej GPS + NETWORK), interwał 20 s w ruchu
  i 60 s na postoju (przełączane automatycznie na podstawie prędkości z fixa), minimalny dystans 75 m.
  Dodatkowo PASSIVE_PROVIDER, czyli darmowe pozycje zamawiane przez inne aplikacje.
- Kompas: `TYPE_ROTATION_VECTOR` z `SENSOR_DELAY_UI`, filtrowanie i próg 1,2 stopnia przed przerysowaniem.
  W trybie "północ" czujnik nie jest w ogóle rejestrowany.
- Przeliczenie obszarów dopiero po przemieszczeniu o ponad 100 m. Pełne przeliczenie 1237 obszarów
  zajmuje kilka ms, więc realnie procesor śpi.

## Dane

`app/src/main/assets/areas.bin` (944 KB) powstaje z Twojego GeoJSON-a przez `tools/build_areas.py`:

- geometria uproszczona algorytmem Douglasa-Peuckera z tolerancją 25 m (185 tys. punktów do 113 tys.),
- powierzchnia brana z pola `ha`,
- współrzędne w mikrostopniach jako int32 (rozdzielczość 11 cm),
- flaga wody.

Przebudowa:

```bash
pip install shapely pyproj
python3 tools/build_areas.py zanocuj-w-lesie.geojson app/src/main/assets/areas.bin \
    --water woda1.geojson woda2.geojson --tol 25 --water-dist 250
```

`tools/verify_bin.py` liczy to samo co silnik w apce i służy do porównania wyników.

### Ograniczenie flagi wody

Twój plik nie zawiera hydrografii, więc wodę trzeba dołożyć z zewnątrz. Użyłem Natural Earth
(10m lakes/rivers, warstwy europejskie), bo tylko to było dostępne offline. To dane w skali
przeglądowej: duże jeziora i większe rzeki, w Polsce 114 obiektów. Flagę dostało 88 z 1237 obszarów,
czyli "obszar przy dużej wodzie", a nie "obszar przy jakimkolwiek cieku". Jeśli chcesz pełną
hydrografię, pobierz warstwę `water` / `waterways` z OSM (Geofabrik: `poland-latest-free.shp.zip`,
warstwy `gis_osm_water_a_free_1` i `gis_osm_waterways_free_1`), skonwertuj do GeoJSON i podaj
w `--water`. Reszta pipeline'u i apki się nie zmienia, próg bliskości ustawia `--water-dist`.

## Strojenie

- `Areas.kt`: `selectForRings(perRing = intArrayOf(6, 4, 3))` to liczba strzałek na pierścień.
  Do każdego pierścienia dokładany jest zawsze największy obszar z tego zakresu.
- `Radar.kt`: `sMin` / `sMax` (rozmiar grotów), `COL_SMALL` / `COL_BIG` / `COL_WATER`, `9.sp` (podpisy).
- `Sensors.kt`: `INTERVAL_MOVING_MS`, `INTERVAL_STILL_MS`, `MIN_DISTANCE_M`.
- `MainActivity.kt`: próg 100 m przeliczania.

## Status weryfikacji

Silnik geometryczny (parser `areas.bin`, odległość do krawędzi, test wnętrza, namiary, wybór
strzałek) skompilowany i uruchomiony na JVM, wyniki zgodne co do cyfry z niezależną implementacją
w Pythonie. Warstwa UI nie była kompilowana: w środowisku, w którym to powstawało, nie ma Android SDK
ani dostępu do repozytorium Google Maven. Układ ekranu był sprawdzany rendererem w Pythonie
odtwarzającym ten sam algorytm rozmieszczania (`tools/mock_radar.py`, podglądy w `podglad/`).
