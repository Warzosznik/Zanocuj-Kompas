# nic specjalnego: brak refleksji, brak serializacji
