package pl.zwl.kompas

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.view.WindowManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlin.math.abs

/* ---------------------------------------------------------------- lokalizacja */

/** Czesciej gdy idziemy, rzadziej gdy stoimy. GPS to glowny konsument pradu. */
private const val INTERVAL_MOVING_MS = 20_000L
private const val INTERVAL_STILL_MS = 60_000L
private const val MIN_DISTANCE_M = 75f

fun hasLocationPermission(ctx: Context): Boolean =
    ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
fun locationFlow(ctx: Context): Flow<Location> = callbackFlow {
    if (!hasLocationPermission(ctx)) {
        close()
        return@callbackFlow
    }
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val providers = ArrayList<String>(3)
    val all = try { lm.allProviders } catch (e: Exception) { emptyList<String>() }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && all.contains(LocationManager.FUSED_PROVIDER)) {
        providers.add(LocationManager.FUSED_PROVIDER)
    } else {
        if (all.contains(LocationManager.GPS_PROVIDER)) providers.add(LocationManager.GPS_PROVIDER)
        if (all.contains(LocationManager.NETWORK_PROVIDER)) providers.add(LocationManager.NETWORK_PROVIDER)
    }

    var interval = INTERVAL_MOVING_MS
    lateinit var listener: LocationListener

    fun register(ms: Long) {
        try {
            lm.removeUpdates(listener)
            for (p in providers) {
                lm.requestLocationUpdates(p, ms, MIN_DISTANCE_M, listener, Looper.getMainLooper())
            }
            // darmowe pozycje z fixow zamowionych przez inne aplikacje
            if (all.contains(LocationManager.PASSIVE_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 10_000L, 50f, listener, Looper.getMainLooper())
            }
        } catch (e: SecurityException) {
            close(e)
        }
    }

    listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            trySend(loc)
            val want = if (loc.hasSpeed() && loc.speed > 0.7f) INTERVAL_MOVING_MS else INTERVAL_STILL_MS
            if (want != interval) {
                interval = want
                register(want)
            }
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("API < 30")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    // natychmiastowy start z ostatniej znanej pozycji
    var last: Location? = null
    for (p in providers + listOf(LocationManager.PASSIVE_PROVIDER)) {
        val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
        if (l != null && (last == null || l.time > last!!.time)) last = l
    }
    last?.let { trySend(it) }

    register(interval)
    awaitClose { try { lm.removeUpdates(listener) } catch (e: Exception) {} }
}

/* -------------------------------------------------------------------- kompas */

/**
 * Azymut urzadzenia wzgledem polnocy geograficznej.
 * Wektor rotacji zamiast surowego magnetometru: mniej szumu, mniej wybudzen.
 */
fun headingFlow(ctx: Context, declinationProvider: () -> Float): Flow<Float> = callbackFlow {
    val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    if (sensor == null) {
        close()
        return@callbackFlow
    }
    val rot = FloatArray(9)
    val remapped = FloatArray(9)
    val orientation = FloatArray(3)
    var smoothed = Float.NaN
    var lastSent = Float.NaN

    val displayRotation = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) ctx.display?.rotation ?: 0
        else @Suppress("DEPRECATION") (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
    } catch (e: Exception) { 0 }

    val (axisX, axisY) = when (displayRotation) {
        1 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
        2 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
        3 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
        else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
    }

    val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            SensorManager.getRotationMatrixFromVector(rot, e.values)
            SensorManager.remapCoordinateSystem(rot, axisX, axisY, remapped)
            SensorManager.getOrientation(remapped, orientation)
            var az = Math.toDegrees(orientation[0].toDouble()).toFloat() + declinationProvider()
            az = ((az % 360f) + 360f) % 360f
            smoothed = if (smoothed.isNaN()) az else {
                var d = az - smoothed
                if (d > 180f) d -= 360f
                if (d < -180f) d += 360f
                ((smoothed + 0.18f * d) % 360f + 360f) % 360f
            }
            var diff = smoothed - lastSent
            if (diff > 180f) diff -= 360f
            if (diff < -180f) diff += 360f
            if (lastSent.isNaN() || abs(diff) > 1.2f) {
                lastSent = smoothed
                trySend(smoothed)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
    awaitClose { sm.unregisterListener(listener) }
}

fun declinationFor(loc: Location?): Float {
    if (loc == null) return 0f
    return GeomagneticField(
        loc.latitude.toFloat(),
        loc.longitude.toFloat(),
        loc.altitude.toFloat(),
        System.currentTimeMillis(),
    ).declination
}
