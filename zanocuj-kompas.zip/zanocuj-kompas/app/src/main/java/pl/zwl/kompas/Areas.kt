package pl.zwl.kompas

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt

/** Metry na jeden mikrostopien szerokosci geograficznej. */
const val M_PER_ULAT = 0.11119493

/** Zasieg zewnetrznego ringu. */
const val MAX_RANGE_M = 90_000f

/**
 * Obszary trzymane w plaskich tablicach prymitywow: zero obiektow na punkt,
 * zero pracy dla GC przy kazdym przeliczeniu.
 *
 * bbox        - 4 wartosci na obszar (minLat, minLon, maxLat, maxLon) w mikrostopniach
 * ringIndex   - count+1 wskaznikow do ringStart
 * ringStart   - liczbaPierscieni+1 wskaznikow do ptLat/ptLon
 */
class AreaStore(
    val count: Int,
    val ha: FloatArray,
    val water: BooleanArray,
    val bbox: IntArray,
    val ringIndex: IntArray,
    val ringStart: IntArray,
    val ptLat: IntArray,
    val ptLon: IntArray,
) {
    companion object {
        fun load(ctx: Context, asset: String = "areas.bin"): AreaStore {
            val bytes = ctx.assets.open(asset).use { it.readBytes() }
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val magic = ByteArray(4).also { bb.get(it) }
            require(String(magic) == "ZWL1") { "zly format pliku areas.bin" }
            val n = bb.int
            val dataStart = bb.position()

            // przebieg 1: policz pierscienie i punkty
            var rings = 0
            var pts = 0
            repeat(n) {
                bb.position(bb.position() + 5)
                val nr = bb.short.toInt() and 0xFFFF
                bb.position(bb.position() + 16)
                rings += nr
                repeat(nr) {
                    val np = bb.int
                    pts += np
                    bb.position(bb.position() + 8 * np)
                }
            }

            val ha = FloatArray(n)
            val water = BooleanArray(n)
            val bbox = IntArray(4 * n)
            val ringIndex = IntArray(n + 1)
            val ringStart = IntArray(rings + 1)
            val ptLat = IntArray(pts)
            val ptLon = IntArray(pts)

            // przebieg 2: wypelnij
            bb.position(dataStart)
            var ri = 0
            var pi = 0
            for (i in 0 until n) {
                ha[i] = bb.float
                water[i] = (bb.get().toInt() and 1) != 0
                val nr = bb.short.toInt() and 0xFFFF
                bbox[4 * i] = bb.int
                bbox[4 * i + 1] = bb.int
                bbox[4 * i + 2] = bb.int
                bbox[4 * i + 3] = bb.int
                ringIndex[i] = ri
                repeat(nr) {
                    val np = bb.int
                    ringStart[ri] = pi
                    repeat(np) {
                        ptLat[pi] = bb.int
                        ptLon[pi] = bb.int
                        pi++
                    }
                    ri++
                }
            }
            ringIndex[n] = ri
            ringStart[ri] = pi
            return AreaStore(n, ha, water, bbox, ringIndex, ringStart, ptLat, ptLon)
        }
    }
}

/** Pojedynczy obszar wzgledem pozycji uzytkownika. */
data class Hit(
    val idx: Int,
    val distM: Float,
    val bearing: Float,
    val ha: Float,
    val water: Boolean,
    val inside: Boolean,
)

/**
 * Odleglosc do najblizszej krawedzi kazdego obszaru w zasiegu plus namiar na ten punkt.
 * Lokalna plaska projekcja wokol pozycji uzytkownika: na 90 km blad ponizej promila.
 */
fun AreaStore.nearest(latDeg: Double, lonDeg: Double, rangeM: Float = MAX_RANGE_M): List<Hit> {
    val lat0u = (latDeg * 1e6).roundToInt()
    val lon0u = (lonDeg * 1e6).roundToInt()
    val mLat = M_PER_ULAT.toFloat()
    val mLon = (M_PER_ULAT * cos(Math.toRadians(latDeg))).toFloat()
    if (mLon <= 0f) return emptyList()
    val dLatU = (rangeM / mLat).toInt()
    val dLonU = (rangeM / mLon).toInt()

    val out = ArrayList<Hit>(64)
    for (a in 0 until count) {
        val mnLa = bbox[4 * a]
        val mnLo = bbox[4 * a + 1]
        val mxLa = bbox[4 * a + 2]
        val mxLo = bbox[4 * a + 3]
        if (mxLa < lat0u - dLatU || mnLa > lat0u + dLatU) continue
        if (mxLo < lon0u - dLonU || mnLo > lon0u + dLonU) continue

        var best = Float.MAX_VALUE
        var bx = 0f
        var by = 0f
        var inside = false

        val r0 = ringIndex[a]
        val r1 = ringIndex[a + 1]
        for (r in r0 until r1) {
            val s = ringStart[r]
            val e = ringStart[r + 1]
            val n = e - s
            if (n < 3) continue
            var jx = (ptLon[e - 1] - lon0u) * mLon
            var jy = (ptLat[e - 1] - lat0u) * mLat
            for (k in s until e) {
                val ix = (ptLon[k] - lon0u) * mLon
                val iy = (ptLat[k] - lat0u) * mLat

                // test parzystosci przeciec promienia +x (punkt uzytkownika = 0,0)
                if ((iy > 0f) != (jy > 0f)) {
                    val xint = ix + (0f - iy) * (jx - ix) / (jy - iy)
                    if (xint > 0f) inside = !inside
                }

                // odleglosc do odcinka i..j
                val vx = jx - ix
                val vy = jy - iy
                val len2 = vx * vx + vy * vy
                var t = if (len2 > 0f) ((-ix) * vx + (-iy) * vy) / len2 else 0f
                if (t < 0f) t = 0f else if (t > 1f) t = 1f
                val qx = ix + t * vx
                val qy = iy + t * vy
                val d2 = qx * qx + qy * qy
                if (d2 < best) {
                    best = d2
                    bx = qx
                    by = qy
                }
                jx = ix
                jy = iy
            }
        }
        if (best == Float.MAX_VALUE) continue
        val dist = if (inside) 0f else kotlin.math.sqrt(best)
        if (dist > rangeM) continue
        val brg = ((Math.toDegrees(atan2(bx.toDouble(), by.toDouble())).toFloat() % 360f) + 360f) % 360f
        out.add(Hit(a, dist, brg, ha[a], water[a], inside))
    }
    out.sortBy { it.distM }
    return out
}

/**
 * Wybor tego, co realnie trafia na ekran: kilka najblizszych w kazdym ringu
 * plus zawsze najwiekszy obszar danego ringu, zeby zielony kolor cos znaczyl.
 */
fun selectForRings(hits: List<Hit>, perRing: IntArray = intArrayOf(6, 4, 3)): List<Hit> {
    val res = ArrayList<Hit>(perRing.sum() + 3)
    for (ring in 0 until 3) {
        val lo = ring * 30_000f
        val hi = lo + 30_000f
        val band = hits.filter { it.distM >= lo && it.distM < hi }
        if (band.isEmpty()) continue
        val take = ArrayList(band.take(perRing[ring]))
        val biggest = band.maxByOrNull { it.ha }!!
        if (take.none { it.idx == biggest.idx }) {
            if (take.size >= perRing[ring] && take.isNotEmpty()) take.removeAt(take.size - 1)
            take.add(biggest)
        }
        res.addAll(take)
    }
    return res
}

/** Odleglosc i namiar do dowolnego punktu (waypoint). */
fun bearingDistance(lat0: Double, lon0: Double, lat1: Double, lon1: Double): Pair<Float, Float> {
    val mLat = M_PER_ULAT * 1e6
    val mLon = mLat * cos(Math.toRadians((lat0 + lat1) / 2.0))
    val x = (lon1 - lon0) * mLon
    val y = (lat1 - lat0) * mLat
    val d = kotlin.math.sqrt(x * x + y * y).toFloat()
    val b = ((Math.toDegrees(atan2(x, y)).toFloat() % 360f) + 360f) % 360f
    return d to b
}

fun formatKm(m: Float): String {
    val km = m / 1000f
    return when {
        m < 100f -> "0 km"
        km < 10f -> String.format("%.1f km", km)
        else -> "${km.roundToInt()} km"
    }
}

fun formatHa(ha: Float): String = "${ha.roundToInt()} ha"

/** Znormalizowana wielkosc obszaru w obrebie tego, co widac na ekranie (0..1). */
fun normalizedSize(ha: Float, minHa: Float, maxHa: Float): Float {
    if (maxHa <= minHa) return 0.5f
    val a = kotlin.math.sqrt(ha)
    val lo = kotlin.math.sqrt(minHa)
    val hi = kotlin.math.sqrt(maxHa)
    return ((a - lo) / (hi - lo)).coerceIn(0f, 1f)
}
