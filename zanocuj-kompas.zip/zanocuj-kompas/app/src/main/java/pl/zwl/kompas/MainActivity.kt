package pl.zwl.kompas

import android.Manifest
import android.content.Context
import android.location.Location
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Obszary wczytujemy raz na proces. */
object Store {
    @Volatile
    private var cached: AreaStore? = null

    fun get(ctx: Context): AreaStore =
        cached ?: synchronized(this) {
            cached ?: AreaStore.load(ctx.applicationContext).also { cached = it }
        }
}

private const val PREFS = "zwl"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val prefs = remember { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    val store by produceState<AreaStore?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { Store.get(ctx) }
    }

    var granted by remember { mutableStateOf(hasLocationPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { granted = hasLocationPermission(ctx) }

    var loc by remember { mutableStateOf<Location?>(null) }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var anchor by remember { mutableStateOf<Location?>(null) }
    var headingUp by remember { mutableStateOf(prefs.getBoolean("headingUp", true)) }
    var heading by remember { mutableFloatStateOf(0f) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }

    var waypoint by remember {
        mutableStateOf(
            if (prefs.contains("wpLat")) {
                LatLon(
                    java.lang.Double.longBitsToDouble(prefs.getLong("wpLat", 0)),
                    java.lang.Double.longBitsToDouble(prefs.getLong("wpLon", 0)),
                )
            } else {
                null
            },
        )
    }
    val declination = remember { mutableFloatStateOf(0f) }

    // pozycja tylko gdy ekran aktywny
    LaunchedEffect(granted) {
        if (!granted) return@LaunchedEffect
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            locationFlow(ctx).collect { l ->
                loc = l
                declination.floatValue = declinationFor(l)
                now = System.currentTimeMillis()
            }
        }
    }

    // kompas tylko w trybie "kompas" i tylko gdy ekran z przodu
    LaunchedEffect(headingUp) {
        if (!headingUp) {
            heading = 0f
            return@LaunchedEffect
        }
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            headingFlow(ctx) { declination.floatValue }.collect { heading = it }
        }
    }

    // wolny zegar tylko po to, zeby ostrzec o starym fixie
    LaunchedEffect(Unit) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) {
                now = System.currentTimeMillis()
                kotlinx.coroutines.delay(60_000L)
            }
        }
    }

    // przeliczenie dopiero po realnym przemieszczeniu
    LaunchedEffect(store, loc) {
        val s = store ?: return@LaunchedEffect
        val l = loc ?: return@LaunchedEffect
        val a = anchor
        if (a == null || a.distanceTo(l) > 100f) {
            anchor = l
            hits = withContext(Dispatchers.Default) {
                selectForRings(s.nearest(l.latitude, l.longitude))
            }
        }
    }

    val user = loc?.let { LatLon(it.latitude, it.longitude) }
    val wp = waypoint
    var wpDist: Float? = null
    var wpBearing: Float? = null
    if (user != null && wp != null) {
        val (d, b) = bearingDistance(user.lat, user.lon, wp.lat, wp.lon)
        wpDist = d
        wpBearing = b
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(COL_BG),
    ) {
        RadarCanvas(
            markers = hits,
            heading = heading,
            waypointDist = wpDist,
            waypointBearing = wpBearing,
            modifier = Modifier.fillMaxSize(),
        )

        store?.let { s ->
            MiniMap(
                store = s,
                user = user,
                waypoint = waypoint,
                onWaypoint = { wp ->
                    waypoint = wp
                    val editor = prefs.edit()
                    if (wp == null) {
                        editor.remove("wpLat").remove("wpLon")
                    } else {
                        editor.putLong("wpLat", java.lang.Double.doubleToRawLongBits(wp.lat))
                        editor.putLong("wpLon", java.lang.Double.doubleToRawLongBits(wp.lon))
                    }
                    editor.apply()
                },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(14.dp),
            )
        }

        BasicText(
            text = if (headingUp) "kompas" else "północ",
            style = TextStyle(color = Color(0x66FFFFFF), fontSize = 10.sp),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .clickable {
                    headingUp = !headingUp
                    prefs.edit().putBoolean("headingUp", headingUp).apply()
                },
        )

        val status = when {
            !granted -> "brak zgody na lokalizację"
            store == null -> "wczytywanie obszarów"
            loc == null -> "czekam na pozycję"
            now - (loc?.time ?: 0L) > 300_000L ->
                "pozycja sprzed ${((now - (loc?.time ?: 0L)) / 60000L).toInt()} min"
            hits.isEmpty() && anchor != null -> "brak obszarów w promieniu 90 km"
            else -> null
        }
        if (status != null) {
            BasicText(
                text = status,
                style = TextStyle(color = Color(0x8CFFFFFF), fontSize = 12.sp, textAlign = TextAlign.Center),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 26.dp)
                    .clickable {
                        if (!granted) {
                            permLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                ),
                            )
                        }
                    },
            )
        }

        LaunchedEffect(Unit) {
            if (!granted) {
                permLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                    ),
                )
            }
        }
    }
}
