package pl.zwl.kompas

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt

data class LatLon(val lat: Double, val lon: Double)

private val COL_MAP_BG = Color(0xFF07070A)
private val COL_FOREST = Color(0xFF16301D)
private val COL_FOREST_EDGE = Color(0xFF2E8C4F)
private val COL_FOREST_WATER = Color(0xFF22C7F0)

/** Rysuje obszary wokol zadanego srodka. Punkty sa przerzedzane wzgledem skali. */
private fun DrawScope.drawAreas(
    store: AreaStore,
    centerLat: Double,
    centerLon: Double,
    mPerPx: Float,
    strokeW: Float,
) {
    val w = size.width
    val h = size.height
    val mLatU = M_PER_ULAT.toFloat()
    val mLonU = (M_PER_ULAT * cos(Math.toRadians(centerLat))).toFloat()
    val lat0u = (centerLat * 1e6).toFloat()
    val lon0u = (centerLon * 1e6).toFloat()
    val halfW = w / 2f
    val halfH = h / 2f
    val spanLatU = (halfH * mPerPx) / mLatU
    val spanLonU = (halfW * mPerPx) / mLonU

    val path = Path()
    var budget = 60_000
    for (a in 0 until store.count) {
        val mnLa = store.bbox[4 * a] - lat0u
        val mnLo = store.bbox[4 * a + 1] - lon0u
        val mxLa = store.bbox[4 * a + 2] - lat0u
        val mxLo = store.bbox[4 * a + 3] - lon0u
        if (mxLa < -spanLatU || mnLa > spanLatU || mxLo < -spanLonU || mnLo > spanLonU) continue

        val pxW = (mxLo - mnLo) * mLonU / mPerPx
        val pxH = (mxLa - mnLa) * mLatU / mPerPx
        val cxp = halfW + (mnLo + mxLo) / 2f * mLonU / mPerPx
        val cyp = halfH - (mnLa + mxLa) / 2f * mLatU / mPerPx
        if (pxW < 3f && pxH < 3f) {
            drawCircle(COL_FOREST_EDGE, 1.5f, Offset(cxp, cyp))
            continue
        }

        path.reset()
        path.fillType = PathFillType.EvenOdd
        val r0 = store.ringIndex[a]
        val r1 = store.ringIndex[a + 1]
        for (r in r0 until r1) {
            val s = store.ringStart[r]
            val e = store.ringStart[r + 1]
            if (e - s < 3) continue
            budget -= (e - s)
            var first = true
            var lastX = 0f
            var lastY = 0f
            for (k in s until e) {
                val x = halfW + (store.ptLon[k] - lon0u) * mLonU / mPerPx
                val y = halfH - (store.ptLat[k] - lat0u) * mLatU / mPerPx
                if (first) {
                    path.moveTo(x, y)
                    first = false
                    lastX = x
                    lastY = y
                } else if (abs(x - lastX) + abs(y - lastY) > 1.2f) {
                    path.lineTo(x, y)
                    lastX = x
                    lastY = y
                }
            }
            path.close()
        }
        drawPath(path, COL_FOREST)
        drawPath(path, if (store.water[a]) COL_FOREST_WATER else COL_FOREST_EDGE, style = Stroke(strokeW))
        if (budget < 0) break
    }
}

private fun DrawScope.drawMarkers(
    userDx: Float,
    userDy: Float,
    wpDx: Float?,
    wpDy: Float?,
    scale: Float,
) {
    val cx = size.width / 2f + userDx
    val cy = size.height / 2f + userDy
    drawCircle(Color.White, 3f * scale, Offset(cx, cy))
    drawCircle(Color(0x66FFFFFF), 7f * scale, Offset(cx, cy), style = Stroke(1f * scale))
    if (wpDx != null && wpDy != null) {
        val x = size.width / 2f + wpDx
        val y = size.height / 2f + wpDy
        val s = 6f * scale
        drawLine(COL_WP, Offset(x - s, y), Offset(x + s, y), 1.5f * scale)
        drawLine(COL_WP, Offset(x, y - s), Offset(x, y + s), 1.5f * scale)
        drawCircle(COL_WP, 2f * scale, Offset(x, y))
    }
}

@Composable
fun MiniMap(
    store: AreaStore,
    user: LatLon?,
    waypoint: LatLon?,
    onWaypoint: (LatLon?) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }

    Box(
        modifier
            .size(76.dp)
            .background(COL_MAP_BG)
            .border(1.dp, Color(0x33FFFFFF))
            .clickable { expanded = true },
    ) {
        if (user != null) {
            Canvas(Modifier.fillMaxSize()) {
                drawAreas(store, user.lat, user.lon, 420f, 1f)
                val (dx, dy) = wpOffset(user, waypoint, 420f, user.lat)
                drawMarkers(0f, 0f, dx, dy, 1f)
            }
        }
    }

    if (expanded) {
        Dialog(
            onDismissRequest = { expanded = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            MapSheet(store, user, waypoint, onWaypoint) { expanded = false }
        }
    }
}

private fun wpOffset(user: LatLon?, wp: LatLon?, mPerPx: Float, refLat: Double): Pair<Float?, Float?> {
    if (user == null || wp == null) return null to null
    val mLat = M_PER_ULAT * 1e6
    val mLon = mLat * cos(Math.toRadians(refLat))
    val dx = ((wp.lon - user.lon) * mLon / mPerPx).toFloat()
    val dy = (-(wp.lat - user.lat) * mLat / mPerPx).toFloat()
    return dx to dy
}

@Composable
private fun MapSheet(
    store: AreaStore,
    user: LatLon?,
    waypoint: LatLon?,
    onWaypoint: (LatLon?) -> Unit,
    onClose: () -> Unit,
) {
    var mapLat by remember { mutableDoubleStateOf(user?.lat ?: 52.0) }
    var mapLon by remember { mutableDoubleStateOf(user?.lon ?: 19.5) }
    var mPerPx by remember { mutableFloatStateOf(120f) }
    val scalePaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.SANS_SERIF
            textSize = 26f
            color = Color(0xB3FFFFFF).toArgb()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(COL_MAP_BG),
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val mLat = M_PER_ULAT * 1e6
                        val mLon = mLat * cos(Math.toRadians(mapLat))
                        mapLon -= pan.x * mPerPx / mLon
                        mapLat += pan.y * mPerPx / mLat
                        mPerPx = (mPerPx / zoom).coerceIn(15f, 3000f)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { off ->
                            val mLat = M_PER_ULAT * 1e6
                            val mLon = mLat * cos(Math.toRadians(mapLat))
                            val lat = mapLat - (off.y - size.height / 2f) * mPerPx / mLat
                            val lon = mapLon + (off.x - size.width / 2f) * mPerPx / mLon
                            onWaypoint(LatLon(lat, lon))
                        },
                        onLongPress = { onWaypoint(null) },
                    )
                },
        ) {
            drawAreas(store, mapLat, mapLon, mPerPx, 1.5f)
            val mLat = M_PER_ULAT * 1e6
            val mLon = mLat * cos(Math.toRadians(mapLat))
            val udx = user?.let { ((it.lon - mapLon) * mLon / mPerPx).toFloat() }
            val udy = user?.let { (-(it.lat - mapLat) * mLat / mPerPx).toFloat() }
            val wdx = waypoint?.let { ((it.lon - mapLon) * mLon / mPerPx).toFloat() }
            val wdy = waypoint?.let { (-(it.lat - mapLat) * mLat / mPerPx).toFloat() }
            if (udx != null && udy != null) drawMarkers(udx, udy, wdx, wdy, 2f)
            else if (wdx != null && wdy != null) drawMarkers(-1e6f, -1e6f, wdx, wdy, 2f)

            // podzialka
            val barM = niceScale(mPerPx * size.width * 0.25f)
            val barPx = barM / mPerPx
            val y = size.height - 60f
            drawLine(Color(0xB3FFFFFF), Offset(40f, y), Offset(40f + barPx, y), 3f)
            drawContext.canvas.nativeCanvas.drawText(
                if (barM >= 1000f) "${(barM / 1000f).roundToInt()} km" else "${barM.roundToInt()} m",
                44f,
                y - 12f,
                scalePaint,
            )
        }

        BasicText(
            text = "dotknij: cel   przytrzymaj: usun cel",
            style = TextStyle(color = Color(0x8CFFFFFF), fontSize = 11.sp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 18.dp),
        )
        BasicText(
            text = "zamknij",
            style = TextStyle(color = Color(0xCCFFFFFF), fontSize = 13.sp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .clickable { onClose() },
        )
    }
}

private fun niceScale(target: Float): Float {
    val steps = floatArrayOf(100f, 200f, 500f, 1000f, 2000f, 5000f, 10_000f, 20_000f, 50_000f, 100_000f)
    for (s in steps) if (s >= target) return s
    return steps.last()
}
