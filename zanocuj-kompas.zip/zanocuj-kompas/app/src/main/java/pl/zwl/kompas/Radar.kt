package pl.zwl.kompas

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

val COL_BG = Color(0xFF000000)
val COL_RING = Color(0x24FFFFFF)
val COL_TEXT = Color(0xB3FFFFFF)
val COL_DIM = Color(0x5AFFFFFF)
val COL_SMALL = Color(0xFFE0392B) // najmniejsze obszary
val COL_BIG = Color(0xFF3FC46A) // najwieksze obszary
val COL_WATER = Color(0xFF22C7F0) // obszar przy wodzie
val COL_WP = Color(0xFFF2F2F2)
val COL_LEADER = Color(0x40FFFFFF)

private data class Placed(val m: Hit, val ux: Float, val uy: Float, val r: Float, val s: Float)

private class LRect(val l: Float, val t: Float, val r: Float, val b: Float) {
    fun overlaps(o: LRect, pad: Float): Boolean =
        l - pad < o.r && r + pad > o.l && t - pad < o.b && b + pad > o.t

    /** Czy okrag o promieniu [rad] wokol (cx,cy) przecina prostokat. */
    fun crossesCircle(cx: Float, cy: Float, rad: Float): Boolean {
        val dx = max(max(l - cx, 0f), cx - r)
        val dy = max(max(t - cy, 0f), cy - b)
        val minD = hypot(dx, dy)
        val maxD = max(
            max(hypot(l - cx, t - cy), hypot(r - cx, t - cy)),
            max(hypot(l - cx, b - cy), hypot(r - cx, b - cy)),
        )
        return rad in minD..maxD
    }
}

@Composable
fun RadarCanvas(
    markers: List<Hit>,
    heading: Float,
    waypointDist: Float?,
    waypointBearing: Float?,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val paint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.SANS_SERIF
            textAlign = Paint.Align.CENTER
            textSize = with(density) { 9.sp.toPx() }
            color = COL_TEXT.toArgb()
        }
    }
    val tickPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.SANS_SERIF
            textAlign = Paint.Align.CENTER
            textSize = with(density) { 7.5f.sp.toPx() }
            color = COL_DIM.toArgb()
        }
    }
    val arrow = remember { Path() }

    Canvas(modifier) {
        drawRadar(this, density, markers, heading, waypointDist, waypointBearing, paint, tickPaint, arrow)
    }
}

private fun drawRadar(
    ds: DrawScope,
    density: Density,
    markers: List<Hit>,
    heading: Float,
    wpDist: Float?,
    wpBearing: Float?,
    paint: Paint,
    tickPaint: Paint,
    arrow: Path,
): Unit = with(ds) {
    fun dp(v: Float) = with(density) { v.dp.toPx() }

    val cx = size.width / 2f
    val cy = size.height * 0.47f
    val outer = min(size.width, size.height) / 2f - dp(24f)
    if (outer <= 0f) return@with
    val rMin = outer * 0.20f
    fun radiusOf(d: Float) = rMin + (outer - rMin) * (d / MAX_RANGE_M).coerceIn(0f, 1f)

    val ringR = floatArrayOf(radiusOf(30_000f), radiusOf(60_000f), outer)
    val dialR = rMin * 0.78f

    // pierscienie
    for (r in ringR) {
        drawCircle(COL_RING, r, Offset(cx, cy), style = Stroke(dp(1f)))
    }

    val placed = ArrayList<LRect>(24)
    val pad = dp(2.5f)

    // opisy pierscieni, wpisane w wolne miejsce przy dole
    val fmTick = tickPaint.fontMetrics
    val tickH = fmTick.descent - fmTick.ascent
    val ticks = arrayOf("30" to ringR[0], "60" to ringR[1], "90" to ringR[2])
    val nc = drawContext.canvas.nativeCanvas
    for ((label, r) in ticks) {
        val tx = cx - dp(3f)
        val ty = cy + r - dp(7f)
        val w = tickPaint.measureText(label)
        val rect = LRect(tx - w / 2 - pad, ty + fmTick.ascent - pad, tx + w / 2 + pad, ty + fmTick.descent + pad)
        placed.add(rect)
        drawRect(COL_BG, Offset(rect.l, rect.t), Size(rect.r - rect.l, rect.b - rect.t))
        nc.drawText(label, tx, ty, tickPaint)
    }

    // polnoc
    run {
        val a = Math.toRadians((-heading).toDouble())
        val ux = sin(a).toFloat()
        val uy = -cos(a).toFloat()
        val nr = outer + dp(11f)
        val nx = cx + ux * nr
        val ny = cy + uy * nr
        val w = tickPaint.measureText("N")
        placed.add(LRect(nx - w, ny - tickH, nx + w, ny + tickH))
        nc.drawText("N", nx, ny + tickH * 0.35f, tickPaint)
    }

    // strefa minimapy i przelacznika, zeby opisy tam nie wchodzily
    placed.add(LRect(0f, size.height - dp(104f), dp(104f), size.height))
    placed.add(LRect(size.width - dp(56f), 0f, size.width, dp(56f)))

    if (markers.isEmpty()) return@with

    var minHa = Float.MAX_VALUE
    var maxHa = 0f
    for (m in markers) {
        if (m.ha < minHa) minHa = m.ha
        if (m.ha > maxHa) maxHa = m.ha
    }

    val sMin = dp(7f)
    val sMax = dp(21f)
    val fm = paint.fontMetrics
    val lineH = (fm.descent - fm.ascent) * 0.92f

    // najpierw wszystkie groty, potem opisy: groty nigdy nie znikaja
    val laid = ArrayList<Placed>(markers.size)
    for (m in markers) {
        val t = normalizedSize(m.ha, minHa, maxHa)
        val s = sMin + (sMax - sMin) * t
        val a = Math.toRadians((m.bearing - heading).toDouble())
        val ux = sin(a).toFloat()
        val uy = -cos(a).toFloat()
        val r = radiusOf(m.distM)
        val px = cx + ux * r
        val py = cy + uy * r
        val vx = -uy
        val vy = ux

        arrow.reset()
        arrow.moveTo(px + ux * s * 0.58f, py + uy * s * 0.58f)
        arrow.lineTo(px - ux * s * 0.42f + vx * s * 0.40f, py - uy * s * 0.42f + vy * s * 0.40f)
        arrow.lineTo(px - ux * s * 0.20f, py - uy * s * 0.20f)
        arrow.lineTo(px - ux * s * 0.42f - vx * s * 0.40f, py - uy * s * 0.42f - vy * s * 0.40f)
        arrow.close()
        val col = if (m.water) COL_WATER else lerpColor(COL_SMALL, COL_BIG, t)
        drawPath(arrow, col)
        placed.add(LRect(px - s * 0.62f, py - s * 0.62f, px + s * 0.62f, py + s * 0.62f))
        laid.add(Placed(m, ux, uy, r, s))
    }

    // opisy: dwa wiersze, nie przecinaja pierscieni, nie nachodza na siebie
    for (p in laid) {
        val l1 = formatKm(p.m.distM)
        val l2 = formatHa(p.m.ha)
        val w = max(paint.measureText(l1), paint.measureText(l2)) + dp(3f)
        val h = 2f * lineH
        val px = cx + p.ux * p.r
        val py = cy + p.uy * p.r
        val vx = -p.uy
        val vy = p.ux

        var best: LRect? = null
        // faza 0: opis nie dotyka zadnego pierscienia; faza 1: dotyka, ale tlo pod tekstem gasi linie
        place@ for (phase in 0..1) {
            for (side in intArrayOf(1, -1)) {
                for (tan in floatArrayOf(0f, 1f, -1f, 1.9f, -1.9f, 2.8f, -2.8f)) {
                    val off = p.s * 0.55f + dp(2f) + h / 2f
                    val lx = px + p.ux * side * off + vx * tan * (w * 0.62f)
                    val ly = py + p.uy * side * off + vy * tan * (w * 0.62f)
                    val rect = LRect(lx - w / 2f, ly - h / 2f, lx + w / 2f, ly + h / 2f)
                    if (rect.l < dp(2f) || rect.r > size.width - dp(2f)) continue
                    if (rect.t < dp(2f) || rect.b > size.height - dp(2f)) continue
                    if (rect.crossesCircle(cx, cy, dialR)) continue
                    if (phase == 0 && ringR.any { rect.crossesCircle(cx, cy, it) }) continue
                    if (placed.any { it.overlaps(rect, pad) }) continue
                    best = rect
                    break@place
                }
            }
        }
        val box = best ?: continue
        placed.add(box)
        val bcx = (box.l + box.r) / 2f
        val bcy = (box.t + box.b) / 2f
        if (kotlin.math.hypot(bcx - px, bcy - py) > p.s * 0.55f + h * 0.95f) {
            drawLine(COL_LEADER, Offset(px, py), Offset(bcx, bcy), dp(0.8f))
        }
        drawRect(COL_BG, Offset(box.l, box.t), Size(box.r - box.l, box.b - box.t))
        val baseline1 = box.t + lineH - fm.descent * 0.4f
        nc.drawText(l1, bcx, baseline1, paint)
        nc.drawText(l2, bcx, baseline1 + lineH, paint)
    }

    // wybrany waypoint: osobna tarcza w srodku
    if (wpDist != null && wpBearing != null) {
        drawCircle(COL_RING, dialR, Offset(cx, cy), style = Stroke(dp(1f)))
        val a = Math.toRadians((wpBearing - heading).toDouble())
        val ux = sin(a).toFloat()
        val uy = -cos(a).toFloat()
        val vx = -uy
        val vy = ux
        val r = dialR * 0.66f
        val s = dp(11f)
        val px = cx + ux * r
        val py = cy + uy * r
        arrow.reset()
        arrow.moveTo(px + ux * s * 0.58f, py + uy * s * 0.58f)
        arrow.lineTo(px - ux * s * 0.42f + vx * s * 0.40f, py - uy * s * 0.42f + vy * s * 0.40f)
        arrow.lineTo(px - ux * s * 0.20f, py - uy * s * 0.20f)
        arrow.lineTo(px - ux * s * 0.42f - vx * s * 0.40f, py - uy * s * 0.42f - vy * s * 0.40f)
        arrow.close()
        drawPath(arrow, COL_WP)
        nc.drawText(formatKm(wpDist), cx, cy + lineH * 0.35f, paint)
    }
}

fun lerpColor(a: Color, b: Color, t: Float): Color {
    val u = t.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * u,
        green = a.green + (b.green - a.green) * u,
        blue = a.blue + (b.blue - a.blue) * u,
        alpha = 1f,
    )
}
