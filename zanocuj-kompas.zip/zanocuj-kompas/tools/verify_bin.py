#!/usr/bin/env python3
"""Sanity-check pliku areas.bin: parsowanie + ta sama logika co w apce."""
import math
import struct
import sys

R = 6371008.8


def load(path):
    b = open(path, "rb").read()
    assert b[:4] == b"ZWL1"
    off = 4
    (n,) = struct.unpack_from("<i", b, off)
    off += 4
    areas = []
    for _ in range(n):
        ha, flags, nring = struct.unpack_from("<fBH", b, off)
        off += 7
        mnlat, mnlon, mxlat, mxlon = struct.unpack_from("<iiii", b, off)
        off += 16
        rings = []
        for _r in range(nring):
            (np_,) = struct.unpack_from("<i", b, off)
            off += 4
            pts = struct.unpack_from("<%di" % (np_ * 2), b, off)
            off += 8 * np_
            rings.append([(pts[i] / 1e6, pts[i + 1] / 1e6) for i in range(0, len(pts), 2)])
        areas.append(
            dict(
                ha=ha,
                water=bool(flags & 1),
                bbox=(mnlat / 1e6, mnlon / 1e6, mxlat / 1e6, mxlon / 1e6),
                rings=rings,
            )
        )
    assert off == len(b), (off, len(b))
    return areas


def seg_dist(px, py, ax, ay, bx, by):
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    L = vx * vx + vy * vy
    t = 0.0 if L == 0 else max(0.0, min(1.0, (wx * vx + wy * vy) / L))
    dx, dy = px - (ax + t * vx), py - (ay + t * vy)
    return math.hypot(dx, dy), ax + t * vx, ay + t * vy


def nearest(areas, lat0, lon0, limit_m=90000):
    mlat = R * math.pi / 180.0
    mlon = mlat * math.cos(math.radians(lat0))
    out = []
    dlat = limit_m / mlat
    dlon = limit_m / mlon
    for a in areas:
        mn_la, mn_lo, mx_la, mx_lo = a["bbox"]
        if mx_la < lat0 - dlat or mn_la > lat0 + dlat or mx_lo < lon0 - dlon or mn_lo > lon0 + dlon:
            continue
        best = 1e18
        bx = by = 0.0
        inside = False
        for ring in a["rings"]:
            n = len(ring)
            j = n - 1
            for i in range(n):
                lat_i, lon_i = ring[i]
                lat_j, lon_j = ring[j]
                if (lat_i > lat0) != (lat_j > lat0):
                    xint = lon_i + (lat0 - lat_i) * (lon_j - lon_i) / (lat_j - lat_i)
                    if lon0 < xint:
                        inside = not inside
                ax, ay = (lon_i - lon0) * mlon, (lat_i - lat0) * mlat
                bx2, by2 = (lon_j - lon0) * mlon, (lat_j - lat0) * mlat
                d, qx, qy = seg_dist(0.0, 0.0, ax, ay, bx2, by2)
                if d < best:
                    best, bx, by = d, qx, qy
                j = i
        if inside:
            best_out = 0.0
        else:
            best_out = best
        if best_out <= limit_m:
            brg = (math.degrees(math.atan2(bx, by)) + 360) % 360
            out.append((best_out, brg, a["ha"], a["water"], inside))
    out.sort(key=lambda x: x[0])
    return out


if __name__ == "__main__":
    areas = load("areas.bin")
    print("obszarow:", len(areas), "przy wodzie:", sum(1 for a in areas if a["water"]))
    print("ha: min %.0f max %.0f" % (min(a["ha"] for a in areas), max(a["ha"] for a in areas)))
    for name, la, lo in [
        ("Warszawa", 52.2297, 21.0122),
        ("Gdansk", 54.352, 18.646),
        ("Krakow", 50.0614, 19.9366),
        ("Bory Tucholskie", 53.90, 18.12),
    ]:
        r = nearest(areas, la, lo)
        print(f"\n== {name}: {len(r)} obszarow w 90 km")
        for d, b, ha, w, ins in r[:6]:
            print(f"   {d/1000:6.1f} km  {b:5.1f}deg  {ha:6.0f} ha  woda={int(w)} wewnatrz={int(ins)}")
