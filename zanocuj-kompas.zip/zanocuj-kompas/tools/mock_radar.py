#!/usr/bin/env python3
"""Podglad ekranu: ten sam uklad co drawRadar() w Kotlinie, rysowany PIL-em."""
import math
import sys

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, "tools")
from verify_bin import load, nearest  # noqa: E402

W, H = 1080, 2100
DP = 2.75  # gestosc typowego telefonu
SP = DP


def dp(v):
    return v * DP


FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", int(9 * SP))
FONT_T = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", int(7.5 * SP))

COL_RING = (36, 36, 36)
COL_SMALL = (224, 57, 43)
COL_BIG = (63, 196, 106)
COL_WATER = (34, 199, 240)
COL_TEXT = (179, 179, 179)
COL_DIM = (90, 90, 90)
COL_WP = (242, 242, 242)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * max(0, min(1, t))) for i in range(3))


def select(hits, per=(6, 4, 3)):
    res = []
    for ring in range(3):
        lo, hi = ring * 30000, ring * 30000 + 30000
        band = [h for h in hits if lo <= h[0] < hi]
        if not band:
            continue
        take = band[: per[ring]]
        big = max(band, key=lambda x: x[2])
        if big not in take:
            take = take[:-1] + [big] if len(take) >= per[ring] else take + [big]
        res += take
    return res


def rect_circle_cross(rect, cx, cy, rad):
    l, t, r, b = rect
    dx = max(l - cx, 0, cx - r)
    dy = max(t - cy, 0, cy - b)
    mn = math.hypot(dx, dy)
    mx = max(math.hypot(x - cx, y - cy) for x in (l, r) for y in (t, b))
    return mn <= rad <= mx


def overlaps(a, b, pad):
    return a[0] - pad < b[2] and a[2] + pad > b[0] and a[1] - pad < b[3] and a[3] + pad > b[1]


def render(markers, heading=0.0, wp=None, out="radar.png"):
    img = Image.new("RGB", (W, H), (0, 0, 0))
    d = ImageDraw.Draw(img)
    cx, cy = W / 2, H * 0.47
    outer = min(W, H) / 2 - dp(24)
    rmin = outer * 0.20

    def rad(dist):
        return rmin + (outer - rmin) * min(1, max(0, dist / 90000))

    rings = [rad(30000), rad(60000), outer]
    dial = rmin * 0.78

    for r in rings:
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=COL_RING, width=int(dp(1)))

    placed = []
    pad = dp(2.5)
    for label, r in zip(("30", "60", "90"), rings):
        tx, ty = cx - dp(3), cy + r - dp(7)
        w = d.textlength(label, font=FONT_T)
        placed.append((tx - w / 2 - pad, ty - 10 * SP - pad, tx + w / 2 + pad, ty + 3 * SP + pad))
        d.text((tx, ty), label, font=FONT_T, fill=COL_DIM, anchor="ms")

    a = math.radians(-heading)
    nr = outer + dp(11)
    nx, ny = cx + math.sin(a) * nr, cy - math.cos(a) * nr
    d.text((nx, ny), "N", font=FONT_T, fill=COL_DIM, anchor="mm")
    placed.append((nx - dp(8), ny - dp(8), nx + dp(8), ny + dp(8)))
    placed.append((0, H - dp(104), dp(104), H))
    placed.append((W - dp(56), 0, W, dp(56)))

    if not markers:
        img.save(out)
        return
    mn = min(m[2] for m in markers)
    mx = max(m[2] for m in markers)

    def norm(ha):
        if mx <= mn:
            return 0.5
        return (math.sqrt(ha) - math.sqrt(mn)) / (math.sqrt(mx) - math.sqrt(mn))

    laid = []
    for dist, brg, ha, water, _ins in markers:
        t = norm(ha)
        s = dp(7) + (dp(21) - dp(7)) * t
        ang = math.radians(brg - heading)
        ux, uy = math.sin(ang), -math.cos(ang)
        r = rad(dist)
        px, py = cx + ux * r, cy + uy * r
        vx, vy = -uy, ux
        pts = [
            (px + ux * s * 0.58, py + uy * s * 0.58),
            (px - ux * s * 0.42 + vx * s * 0.40, py - uy * s * 0.42 + vy * s * 0.40),
            (px - ux * s * 0.20, py - uy * s * 0.20),
            (px - ux * s * 0.42 - vx * s * 0.40, py - uy * s * 0.42 - vy * s * 0.40),
        ]
        col = COL_WATER if water else lerp(COL_SMALL, COL_BIG, t)
        d.polygon(pts, fill=col)
        placed.append((px - s * 0.62, py - s * 0.62, px + s * 0.62, py + s * 0.62))
        laid.append((dist, brg, ha, ux, uy, r, s, px, py))

    lineH = 11.5 * SP
    dropped = 0
    for dist, brg, ha, ux, uy, r, s, px, py in laid:
        l1 = ("%.1f km" % (dist / 1000)) if dist < 10000 else ("%d km" % round(dist / 1000))
        if dist < 100:
            l1 = "0 km"
        l2 = "%d ha" % round(ha)
        w = max(d.textlength(l1, font=FONT), d.textlength(l2, font=FONT)) + dp(3)
        h = 2 * lineH
        vx, vy = -uy, ux
        best = None
        for phase in (0, 1):
            for side in (1, -1):
                for tan in (0, 1, -1, 1.9, -1.9, 2.8, -2.8):
                    off = s * 0.55 + dp(2) + h / 2
                    lx = px + ux * side * off + vx * tan * (w * 0.62)
                    ly = py + uy * side * off + vy * tan * (w * 0.62)
                    rect = (lx - w / 2, ly - h / 2, lx + w / 2, ly + h / 2)
                    if rect[0] < dp(2) or rect[2] > W - dp(2):
                        continue
                    if rect[1] < dp(2) or rect[3] > H - dp(2):
                        continue
                    if rect_circle_cross(rect, cx, cy, dial):
                        continue
                    if phase == 0 and any(rect_circle_cross(rect, cx, cy, rr) for rr in rings):
                        continue
                    if any(overlaps(rect, o, pad) for o in placed):
                        continue
                    best = rect
                    break
                if best:
                    break
            if best:
                break
        if not best:
            dropped += 1
            continue
        placed.append(best)
        bcx, bcy = (best[0] + best[2]) / 2, (best[1] + best[3]) / 2
        if math.hypot(bcx - px, bcy - py) > s * 0.55 + h * 0.95:
            d.line([(px, py), (bcx, bcy)], fill=(70, 70, 70), width=int(dp(0.8)))
        d.rectangle(best, fill=(0, 0, 0))
        bx = (best[0] + best[2]) / 2
        b1 = best[1] + lineH - 0.4 * 3 * SP
        d.text((bx, b1), l1, font=FONT, fill=COL_TEXT, anchor="ms")
        d.text((bx, b1 + lineH), l2, font=FONT, fill=COL_TEXT, anchor="ms")

    if wp:
        wd, wb = wp
        d.ellipse([cx - dial, cy - dial, cx + dial, cy + dial], outline=COL_RING, width=int(dp(1)))
        ang = math.radians(wb - heading)
        ux, uy = math.sin(ang), -math.cos(ang)
        vx, vy = -uy, ux
        r = dial * 0.66
        s = dp(11)
        px, py = cx + ux * r, cy + uy * r
        d.polygon(
            [
                (px + ux * s * 0.58, py + uy * s * 0.58),
                (px - ux * s * 0.42 + vx * s * 0.40, py - uy * s * 0.42 + vy * s * 0.40),
                (px - ux * s * 0.20, py - uy * s * 0.20),
                (px - ux * s * 0.42 - vx * s * 0.40, py - uy * s * 0.42 - vy * s * 0.40),
            ],
            fill=COL_WP,
        )
        d.text((cx, cy + lineH * 0.35), ("%.1f km" % (wd / 1000)) if wd < 10000 else "%d km" % round(wd / 1000), font=FONT, fill=COL_TEXT, anchor="ms")

    # minimapa
    d.rectangle([dp(14), H - dp(90), dp(90), H - dp(14)], outline=(60, 60, 60))
    d.text((W - dp(16), dp(20)), "kompas", font=FONT_T, fill=(102, 102, 102), anchor="rs")
    img.save(out)
    print(f"{out}: pominietych opisow {dropped}/{len(laid)}")


if __name__ == "__main__":
    areas = load("areas.bin")
    for name, la, lo, wp in [
        ("warszawa", 52.2297, 21.0122, (8300.0, 47.0)),
        ("krakow", 50.0614, 19.9366, None),
        ("gdansk", 54.352, 18.646, (23000.0, 300.0)),
    ]:
        hits = nearest(areas, la, lo)
        render(select(hits), heading=0.0, wp=wp, out=f"mock_{name}.png")
