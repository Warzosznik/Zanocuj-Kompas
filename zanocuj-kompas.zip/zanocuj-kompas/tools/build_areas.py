#!/usr/bin/env python3
"""
Zamienia GeoJSON programu "Zanocuj w lesie" na kompaktowy plik binarny (.bin),
ktory aplikacja wczytuje z assets/.

Uzycie:
  python3 build_areas.py zanocuj-w-lesie.geojson areas.bin \
      [--water plik_z_woda.geojson ...] [--tol 25] [--water-dist 250]

Format pliku (little-endian):
  magic      char[4]  "ZWL1"
  areaCount  int32
  dla kazdego obszaru:
    ha         float32
    flags      uint8      (bit0 = 1 -> obszar przy wodzie)
    ringCount  uint16
    minLat,minLon,maxLat,maxLon  int32 x4   (mikrostopnie, 1e-6 deg)
    dla kazdego pierscienia:
      pointCount int32
      punkty:    int32 lat, int32 lon (mikrostopnie), pointCount razy
Pierscien nr 0 to kontur zewnetrzny, kolejne to dziury.
"""
import argparse
import json
import struct
import sys

from shapely.geometry import shape, MultiPolygon, Polygon
from shapely.ops import transform as shp_transform
from shapely.strtree import STRtree
from pyproj import Transformer

WGS84 = "EPSG:4326"
PL92 = "EPSG:2180"  # PUWG 1992, metry, dobre dla calej Polski

to_m = Transformer.from_crs(WGS84, PL92, always_xy=True).transform
to_deg = Transformer.from_crs(PL92, WGS84, always_xy=True).transform


def load_features(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if data.get("type") == "FeatureCollection":
        return data["features"]
    return [data]


def water_geoms(paths, bbox_deg):
    """Wczytuje warstwy wodne, przycina do bboxa Polski, zwraca liste geometrii w metrach."""
    from shapely.geometry import box

    clip = box(*bbox_deg)
    out = []
    for p in paths:
        for feat in load_features(p):
            geom = feat.get("geometry")
            if not geom:
                continue
            try:
                g = shape(geom)
            except Exception:
                continue
            if g.is_empty or not g.intersects(clip):
                continue
            g = g.intersection(clip)
            if g.is_empty:
                continue
            out.append(shp_transform(to_m, g))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--water", nargs="*", default=[])
    ap.add_argument("--tol", type=float, default=25.0, help="tolerancja upraszczania [m]")
    ap.add_argument("--water-dist", type=float, default=250.0, help="prog bliskosci wody [m]")
    args = ap.parse_args()

    feats = load_features(args.src)
    print(f"obszarow wejsciowych: {len(feats)}")

    water = water_geoms(args.water, (13.5, 48.5, 25.0, 55.5)) if args.water else []
    tree = STRtree(water) if water else None
    print(f"obiektow wodnych po przycieciu: {len(water)}")

    records = []
    pts_in = pts_out = 0
    n_water = 0

    for feat in feats:
        props = feat.get("properties") or {}
        ha = props.get("ha")
        geom = shape(feat["geometry"])
        g_m = shp_transform(to_m, geom)
        if not g_m.is_valid:
            g_m = g_m.buffer(0)
        if ha is None:
            ha = g_m.area / 10000.0
        # uproszczenie w metrach, zachowujac topologie
        simp = g_m.simplify(args.tol, preserve_topology=True)
        if simp.is_empty or not simp.is_valid:
            simp = g_m if g_m.is_valid else g_m.buffer(0)
        polys = list(simp.geoms) if isinstance(simp, MultiPolygon) else [simp]

        near_water = False
        if tree is not None:
            idx = tree.query(simp.buffer(args.water_dist))
            for i in idx:
                if water[i].distance(simp) <= args.water_dist:
                    near_water = True
                    break
        if near_water:
            n_water += 1

        rings = []
        for poly in polys:
            if not isinstance(poly, Polygon) or poly.is_empty:
                continue
            for ring in [poly.exterior] + list(poly.interiors):
                r = shp_transform(to_deg, ring)
                coords = list(r.coords)
                if len(coords) > 1 and coords[0] == coords[-1]:
                    coords = coords[:-1]  # zamkniecie domyslne
                if len(coords) < 3:
                    continue
                rings.append(coords)

        if not rings:
            continue

        for poly in polys:
            pts_in += 0
        pts_out += sum(len(r) for r in rings)
        pts_in += sum(
            len(p.exterior.coords) + sum(len(i.coords) for i in p.interiors)
            for p in (list(g_m.geoms) if isinstance(g_m, MultiPolygon) else [g_m])
        )

        records.append((float(ha), near_water, rings))

    print(f"punktow: {pts_in} -> {pts_out}")
    print(f"obszarow przy wodzie: {n_water}")

    print(f"max pierscieni w obszarze: {max(len(r[2]) for r in records)}")

    with open(args.dst, "wb") as f:
        f.write(b"ZWL1")
        f.write(struct.pack("<i", len(records)))
        for ha, wet, rings in records:

            lats = [p[1] for r in rings for p in r]
            lons = [p[0] for r in rings for p in r]
            f.write(struct.pack("<fBH", ha, 1 if wet else 0, len(rings)))
            f.write(
                struct.pack(
                    "<iiii",
                    int(round(min(lats) * 1e6)),
                    int(round(min(lons) * 1e6)),
                    int(round(max(lats) * 1e6)),
                    int(round(max(lons) * 1e6)),
                )
            )
            for r in rings:
                f.write(struct.pack("<i", len(r)))
                buf = bytearray()
                for lon, lat in r:
                    buf += struct.pack("<ii", int(round(lat * 1e6)), int(round(lon * 1e6)))
                f.write(buf)

    import os

    print(f"zapisano {args.dst}: {os.path.getsize(args.dst)/1024:.0f} KB")


if __name__ == "__main__":
    main()
