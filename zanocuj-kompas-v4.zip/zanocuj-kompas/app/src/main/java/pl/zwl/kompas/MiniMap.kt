package pl.zwl.kompas

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sinh

data class LatLon(val lat: Double, val lon: Double)

private val COL_MAP_BG = Color(0xFF07070A)
private val COL_FOREST = Color(0x5916301D)
private val COL_FOREST_EDGE = Color(0xFF3BE07C)
private val COL_FOREST_WATER = Color(0xFF2FD8FF)
private val COL_MAP_RING = Color(0x73FFFFFF)

/* ------------------------------------------------------------- Web Mercator */

private const val TILE = 256.0

private fun lonToX(lon: Double, scale: Double) = (lon + 180.0) / 360.0 * scale

private fun latToY(lat: Double, scale: Double): Double {
    val s = sin(Math.toRadians(lat.coerceIn(-85.05, 85.05)))
    return (0.5 - ln((1 + s) / (1 - s)) / (4 * PI)) * scale
}

private fun xToLon(x: Double, scale: Double) = x / scale * 360.0 - 180.0

private fun yToLat(y: Double, scale: Double): Double {
    val n = PI * (1 - 2 * y / scale)
    return Math.toDegrees(atan(sinh(n)))
}

private fun metersPerPixel(lat: Double, zoom: Float): Double =
    156543.03392 * cos(Math.toRadians(lat)) / 2.0.pow(zoom.toDouble())

/* -------------------------------------------------------------- kafle z OSM */

/**
 * Kafle OSM: pamięć podręczna w RAM i na dysku. Pobieranie tylko dla widocznego
 * fragmentu, więc ruch sieciowy jest znikomy, a raz pobrany teren działa offline.
 */
/** Źródła podkładu. OSM standard bywa blokowany dla aplikacji, dlatego nie jest domyślny. */
object TileSource {
    const val DARK = 0
    const val TOPO = 1
    const val OSM = 2

    fun name(style: Int) = when (style) {
        TOPO -> "topo"
        OSM -> "OSM"
        else -> "ciemna"
    }

    fun attribution(style: Int) = when (style) {
        TOPO -> "Esri, USGS, NGA, OpenStreetMap"
        OSM -> "© OpenStreetMap contributors"
        else -> "© OpenStreetMap contributors, © CARTO"
    }

    fun url(style: Int, z: Int, x: Int, y: Int) = when (style) {
        TOPO -> "https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/$z/$y/$x"
        OSM -> "https://tile.openstreetmap.org/$z/$x/$y.png"
        else -> "https://basemaps.cartocdn.com/dark_all/$z/$x/$y.png"
    }
}

/**
 * Kafle: pamięć podręczna w RAM i na dysku. Pobieranie tylko dla widocznego fragmentu,
 * więc ruch sieciowy jest znikomy, a raz pobrany teren działa offline.
 * Zapisujemy wyłącznie odpowiedzi 200, żeby nie zakleić cache stronami błędów.
 */
object Tiles {
    private const val MAX_MEM = 160
    private val mem = LruCache<String, ImageBitmap>(MAX_MEM)
    private val pending = Collections.synchronizedSet(HashSet<String>())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Rośnie po każdym wczytanym kaflu, żeby wymusić przerysowanie mapy. */
    val version = mutableIntStateOf(0)

    fun get(ctx: Context, style: Int, z: Int, x: Int, y: Int): ImageBitmap? {
        val key = "$style/$z/$x/$y"
        mem.get(key)?.let { return it }
        if (!pending.add(key)) return null
        val app = ctx.applicationContext
        scope.launch {
            var f: File? = null
            try {
                val dir = File(app.cacheDir, "tiles-v2/$style")
                dir.mkdirs()
                val file = File(dir, "${z}_${x}_$y.png")
                f = file
                if (!file.exists() || file.length() == 0L) {
                    val conn = URL(TileSource.url(style, z, x, y)).openConnection() as HttpURLConnection
                    conn.setRequestProperty(
                        "User-Agent",
                        "ZanocujKompas/1.0 (+https://github.com/Warzosznik/Zanocuj-Kompas)",
                    )
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    val code = conn.responseCode
                    if (code == 200) {
                        conn.inputStream.use { input -> file.outputStream().use { input.copyTo(it) } }
                    }
                    conn.disconnect()
                    if (code != 200) {
                        file.delete()
                        return@launch
                    }
                }
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp == null) {
                    file.delete()
                    return@launch
                }
                val img = bmp.asImageBitmap()
                withContext(Dispatchers.Main) {
                    mem.put(key, img)
                    version.intValue++
                }
            } catch (e: Exception) {
                f?.delete()
                // brak sieci albo błąd serwera: mapa zostaje wektorowa
            } finally {
                pending.remove(key)
            }
        }
        return null
    }
}

/* ------------------------------------------------------------------ rysunek */

private fun DrawScope.drawTiles(ctx: Context, style: Int, centerLat: Double, centerLon: Double, zoom: Float) {
    Tiles.version.intValue // rejestracja odczytu: nowy kafel wymusi przerysowanie
    val zi = floor(zoom.toDouble()).toInt().coerceIn(1, 19)
    val scale = TILE * 2.0.pow(zoom.toDouble())
    val scaleI = TILE * 2.0.pow(zi.toDouble())
    val f = scaleI / scale // world(zi) -> ekran: dziel przez f

    val cxW = lonToX(centerLon, scaleI)
    val cyW = latToY(centerLat, scaleI)
    val leftW = cxW - (size.width / 2f) * f
    val topW = cyW - (size.height / 2f) * f
    val rightW = cxW + (size.width / 2f) * f
    val bottomW = cyW + (size.height / 2f) * f

    val n = 1 shl zi
    val tx0 = floor(leftW / TILE).toInt()
    val tx1 = floor(rightW / TILE).toInt()
    val ty0 = floor(topW / TILE).toInt().coerceIn(0, n - 1)
    val ty1 = floor(bottomW / TILE).toInt().coerceIn(0, n - 1)
    if ((tx1 - tx0 + 1) * (ty1 - ty0 + 1) > 48) return

    val screenTile = (TILE / f).toFloat()
    for (tx in tx0..tx1) {
        for (ty in ty0..ty1) {
            val wrapX = ((tx % n) + n) % n
            val img = Tiles.get(ctx, style, zi, wrapX, ty) ?: continue
            val sx = ((tx * TILE - leftW) / f).toFloat()
            val sy = ((ty * TILE - topW) / f).toFloat()
            drawImage(
                image = img,
                dstOffset = IntOffset(sx.roundToInt(), sy.roundToInt()),
                dstSize = IntSize(screenTile.roundToInt() + 1, screenTile.roundToInt() + 1),
                alpha = 0.9f,
            )
        }
    }
}

private fun DrawScope.drawAreasMercator(
    store: AreaStore,
    centerLat: Double,
    centerLon: Double,
    zoom: Float,
    strokeW: Float,
) {
    val scale = TILE * 2.0.pow(zoom.toDouble())
    val cxW = lonToX(centerLon, scale)
    val cyW = latToY(centerLat, scale)
    val halfW = size.width / 2f
    val halfH = size.height / 2f
    val minLon = xToLon(cxW - halfW, scale)
    val maxLon = xToLon(cxW + halfW, scale)
    val maxLat = yToLat(cyW - halfH, scale)
    val minLat = yToLat(cyW + halfH, scale)

    val path = Path()
    var budget = 60_000
    for (a in 0 until store.count) {
        val mnLa = store.bbox[4 * a] / 1e6
        val mnLo = store.bbox[4 * a + 1] / 1e6
        val mxLa = store.bbox[4 * a + 2] / 1e6
        val mxLo = store.bbox[4 * a + 3] / 1e6
        if (mxLa < minLat || mnLa > maxLat || mxLo < minLon || mnLo > maxLon) continue

        val x0 = (lonToX(mnLo, scale) - cxW + halfW).toFloat()
        val x1 = (lonToX(mxLo, scale) - cxW + halfW).toFloat()
        val y0 = (latToY(mxLa, scale) - cyW + halfH).toFloat()
        val y1 = (latToY(mnLa, scale) - cyW + halfH).toFloat()
        if (x1 - x0 < 3f && y1 - y0 < 3f) {
            drawCircle(COL_FOREST_EDGE, 1.5f, Offset((x0 + x1) / 2f, (y0 + y1) / 2f))
            continue
        }

        path.reset()
        path.fillType = PathFillType.EvenOdd
        val r0 = store.ringIndex[a]
        val r1 = store.ringIndex[a + 1]
        for (r in r0 until r1) {
            val s = store.ringStart[r]
            val e = store.ringStart[r + 1]
            if (e - s < 3) continue
            budget -= (e - s)
            var first = true
            var lastX = 0f
            var lastY = 0f
            for (k in s until e) {
                val x = (lonToX(store.ptLon[k] / 1e6, scale) - cxW + halfW).toFloat()
                val y = (latToY(store.ptLat[k] / 1e6, scale) - cyW + halfH).toFloat()
                if (first) {
                    path.moveTo(x, y)
                    first = false
                    lastX = x
                    lastY = y
                } else if (abs(x - lastX) + abs(y - lastY) > 1.2f) {
                    path.lineTo(x, y)
                    lastX = x
                    lastY = y
                }
            }
            path.close()
        }
        drawPath(path, COL_FOREST)
        drawPath(path, if (store.water[a]) COL_FOREST_WATER else COL_FOREST_EDGE, style = Stroke(strokeW))
        if (budget < 0) break
    }
}

private fun DrawScope.drawOverlay(
    user: LatLon?,
    waypoint: LatLon?,
    ringsKm: IntArray,
    centerLat: Double,
    centerLon: Double,
    zoom: Float,
    scaleUi: Float,
) {
    val scale = TILE * 2.0.pow(zoom.toDouble())
    val cxW = lonToX(centerLon, scale)
    val cyW = latToY(centerLat, scale)
    fun sx(lon: Double) = (lonToX(lon, scale) - cxW + size.width / 2f).toFloat()
    fun sy(lat: Double) = (latToY(lat, scale) - cyW + size.height / 2f).toFloat()

    if (user != null) {
        val ux = sx(user.lon)
        val uy = sy(user.lat)
        val mpp = metersPerPixel(user.lat, zoom)
        for (km in ringsKm) {
            drawCircle(COL_MAP_RING, (km * 1000.0 / mpp).toFloat(), Offset(ux, uy), style = Stroke(1f * scaleUi))
        }
        drawCircle(Color.White, 3f * scaleUi, Offset(ux, uy))
        drawCircle(Color(0x99FFFFFF), 7f * scaleUi, Offset(ux, uy), style = Stroke(1f * scaleUi))
    }
    if (waypoint != null) {
        val x = sx(waypoint.lon)
        val y = sy(waypoint.lat)
        val s = 6f * scaleUi
        drawLine(COL_WP, Offset(x - s, y), Offset(x + s, y), 1.5f * scaleUi)
        drawLine(COL_WP, Offset(x, y - s), Offset(x, y + s), 1.5f * scaleUi)
        drawCircle(COL_WP, 2f * scaleUi, Offset(x, y))
    }
}

/* -------------------------------------------------------------- kompozytowe */

@Composable
fun MiniMap(
    store: AreaStore,
    user: LatLon?,
    waypoint: LatLon?,
    ringsKm: IntArray,
    tilesEnabled: Boolean,
    mapStyle: Int,
    onWaypoint: (LatLon?) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    Box(
        modifier
            .size(84.dp)
            .background(COL_MAP_BG)
            .border(1.dp, Color(0x66FFFFFF))
            .clickable { expanded = true },
    ) {
        if (user != null) {
            Canvas(Modifier.fillMaxSize()) {
                // dobierz zoom tak, żeby ostatni pierścień mieścił się w kwadracie
                val wantMpp = ringsKm[2] * 1000.0 / (size.minDimension * 0.46)
                val zoom = log2(156543.03392 * cos(Math.toRadians(user.lat)) / wantMpp)
                    .toFloat().coerceIn(3f, 16f)
                if (tilesEnabled) drawTiles(ctx, mapStyle, user.lat, user.lon, zoom)
                drawAreasMercator(store, user.lat, user.lon, zoom, 1f)
                drawOverlay(user, waypoint, ringsKm, user.lat, user.lon, zoom, 1f)
            }
        }
    }

    if (expanded) {
        Dialog(
            onDismissRequest = { expanded = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            MapSheet(store, user, waypoint, ringsKm, tilesEnabled, mapStyle, onWaypoint) { expanded = false }
        }
    }
}

@Composable
private fun MapSheet(
    store: AreaStore,
    user: LatLon?,
    waypoint: LatLon?,
    ringsKm: IntArray,
    tilesEnabled: Boolean,
    mapStyle: Int,
    onWaypoint: (LatLon?) -> Unit,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    var mapLat by remember { mutableDoubleStateOf(user?.lat ?: 52.0) }
    var mapLon by remember { mutableDoubleStateOf(user?.lon ?: 19.5) }
    var zoom by remember { mutableFloatStateOf(11f) }

    Box(Modifier.fillMaxSize().background(COL_MAP_BG)) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, gestureZoom, _ ->
                        val scale = TILE * 2.0.pow(zoom.toDouble())
                        val cxW = lonToX(mapLon, scale) - pan.x
                        val cyW = latToY(mapLat, scale) - pan.y
                        mapLon = xToLon(cxW, scale)
                        mapLat = yToLat(cyW, scale)
                        if (gestureZoom != 1f) {
                            zoom = (zoom + log2(gestureZoom)).coerceIn(4f, 17f)
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { off ->
                            val scale = TILE * 2.0.pow(zoom.toDouble())
                            val cxW = lonToX(mapLon, scale)
                            val cyW = latToY(mapLat, scale)
                            val lon = xToLon(cxW + (off.x - size.width / 2f), scale)
                            val lat = yToLat(cyW + (off.y - size.height / 2f), scale)
                            onWaypoint(LatLon(lat, lon))
                        },
                        onLongPress = { onWaypoint(null) },
                    )
                },
        ) {
            if (tilesEnabled) drawTiles(ctx, mapStyle, mapLat, mapLon, zoom)
            drawAreasMercator(store, mapLat, mapLon, zoom, 1.5f)
            drawOverlay(user, waypoint, ringsKm, mapLat, mapLon, zoom, 2f)
        }

        BasicText(
            text = "dotknij: cel   przytrzymaj: usuń cel",
            style = TextStyle(color = Color(0xB3FFFFFF), fontSize = 11.sp),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp),
        )

        val d = if (user != null && waypoint != null) {
            bearingDistance(user.lat, user.lon, waypoint.lat, waypoint.lon).first
        } else {
            null
        }
        BasicText(
            text = if (d != null) "cel ${formatKm(d)}" else "cel nie ustawiony",
            style = TextStyle(color = Color.White, fontSize = 14.sp),
            modifier = Modifier.align(Alignment.BottomStart).padding(24.dp),
        )
        if (tilesEnabled) {
            BasicText(
                text = TileSource.attribution(mapStyle),
                style = TextStyle(color = Color(0x8CFFFFFF), fontSize = 9.sp),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp),
            )
        }
        BasicText(
            text = "zamknij",
            style = TextStyle(color = Color.White, fontSize = 14.sp),
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp).clickable { onClose() },
        )
    }
}
