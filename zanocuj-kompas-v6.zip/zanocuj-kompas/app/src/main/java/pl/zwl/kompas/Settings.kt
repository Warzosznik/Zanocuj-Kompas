package pl.zwl.kompas

import android.content.SharedPreferences
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.roundToInt

/** perRing = 0 oznacza brak limitu. */
data class Settings(
    val r1: Int = 30,
    val r2: Int = 60,
    val r3: Int = 90,
    val perRing: Int = 6,
    val tiles: Boolean = true,
    val mapStyle: Int = TileSource.TOPO,
    val tileAlpha: Float = 1f,
    val arrowScale: Float = 1f,
    val textScale: Float = 1f,
    val ringAlpha: Float = 0.6f,
    val keepScreenOn: Boolean = true,
    val headingUp: Boolean = true,
) {
    val ringsKm: IntArray get() = intArrayOf(r1, r2, r3)
    val rangeM: Float get() = r3 * 1000f

    fun save(p: SharedPreferences) {
        p.edit()
            .putInt("r1", r1).putInt("r2", r2).putInt("r3", r3)
            .putInt("perRing", perRing)
            .putBoolean("tiles", tiles)
            .putInt("mapStyle", mapStyle)
            .putFloat("tileAlpha", tileAlpha)
            .putFloat("arrowScale", arrowScale)
            .putFloat("textScale", textScale)
            .putFloat("ringAlpha", ringAlpha)
            .putBoolean("keepScreenOn", keepScreenOn)
            .putBoolean("headingUp", headingUp)
            .apply()
    }

    companion object {
        val PER_RING_STEPS = intArrayOf(3, 5, 6, 8, 12, 20, 0)

        fun load(p: SharedPreferences) = Settings(
            r1 = p.getInt("r1", 30),
            r2 = p.getInt("r2", 60),
            r3 = p.getInt("r3", 90),
            perRing = p.getInt("perRing", 6),
            tiles = p.getBoolean("tiles", true),
            mapStyle = p.getInt("mapStyle", TileSource.TOPO),
            tileAlpha = p.getFloat("tileAlpha", 1f),
            arrowScale = p.getFloat("arrowScale", 1f),
            textScale = p.getFloat("textScale", 1f),
            ringAlpha = p.getFloat("ringAlpha", 0.6f),
            keepScreenOn = p.getBoolean("keepScreenOn", true),
            headingUp = p.getBoolean("headingUp", true),
        )
    }
}

private val LABEL = TextStyle(color = Color(0xFFEDEDED), fontSize = 14.sp)
private val VALUE = TextStyle(color = Color(0xFFFFFFFF), fontSize = 14.sp, textAlign = TextAlign.Center)
private val BTN = TextStyle(color = Color(0xFFFFFFFF), fontSize = 20.sp, textAlign = TextAlign.Center)
private val HINT = TextStyle(color = Color(0x8CFFFFFF), fontSize = 11.sp)

@Composable
private fun StepperRow(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicText(label, style = LABEL, modifier = Modifier.weight(1f))
        Box(Modifier.size(44.dp).clickable { onMinus() }, contentAlignment = Alignment.Center) {
            BasicText("−", style = BTN)
        }
        Box(Modifier.size(80.dp, 44.dp), contentAlignment = Alignment.Center) {
            BasicText(value, style = VALUE)
        }
        Box(Modifier.size(44.dp).clickable { onPlus() }, contentAlignment = Alignment.Center) {
            BasicText("+", style = BTN)
        }
    }
}

@Composable
private fun ToggleRow(label: String, on: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onToggle() }.padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicText(label, style = LABEL, modifier = Modifier.weight(1f))
        BasicText(if (on) "włączone" else "wyłączone", style = VALUE)
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    text: String,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicText(label, style = LABEL, modifier = Modifier.weight(1f))
            BasicText(text, style = VALUE)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(40.dp)
                .pointerInput(min, max) {
                    detectTapGestures { off ->
                        onChange(min + (max - min) * (off.x / size.width).coerceIn(0f, 1f))
                    }
                }
                .pointerInput(min, max) {
                    detectHorizontalDragGestures { change, _ ->
                        onChange(min + (max - min) * (change.position.x / size.width).coerceIn(0f, 1f))
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val t = ((value - min) / (max - min)).coerceIn(0f, 1f)
                drawLine(Color(0x40FFFFFF), Offset(0f, y), Offset(size.width, y), 3f)
                drawLine(Color.White, Offset(0f, y), Offset(size.width * t, y), 3f)
                drawCircle(Color.White, 14f, Offset(size.width * t, y))
            }
        }
    }
}

@Composable
fun SettingsSheet(s: Settings, onChange: (Settings) -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xFF000000))) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 36.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                BasicText("ustawienia", style = TextStyle(color = Color.White, fontSize = 18.sp))

                BasicText(
                    "zakresy pierścieni, licząc od Twojej pozycji",
                    style = HINT,
                    modifier = Modifier.padding(top = 16.dp, bottom = 2.dp),
                )
                StepperRow(
                    "pierścień 1", "0 - ${s.r1} km",
                    { if (s.r1 > 5) onChange(s.copy(r1 = s.r1 - 5)) },
                    { if (s.r1 + 5 < s.r2) onChange(s.copy(r1 = s.r1 + 5)) },
                )
                StepperRow(
                    "pierścień 2", "${s.r1} - ${s.r2} km",
                    { if (s.r2 - 5 > s.r1) onChange(s.copy(r2 = s.r2 - 5)) },
                    { if (s.r2 + 5 < s.r3) onChange(s.copy(r2 = s.r2 + 5)) },
                )
                StepperRow(
                    "pierścień 3", "${s.r2} - ${s.r3} km",
                    { if (s.r3 - 5 > s.r2) onChange(s.copy(r3 = s.r3 - 5)) },
                    { if (s.r3 < 300) onChange(s.copy(r3 = s.r3 + 5)) },
                )
                StepperRow(
                    "strzałek na pierścień", if (s.perRing == 0) "wszystkie" else "${s.perRing}",
                    {
                        val i = Settings.PER_RING_STEPS.indexOf(s.perRing)
                        if (i > 0) onChange(s.copy(perRing = Settings.PER_RING_STEPS[i - 1]))
                    },
                    {
                        val i = Settings.PER_RING_STEPS.indexOf(s.perRing)
                        if (i in 0 until Settings.PER_RING_STEPS.size - 1) {
                            onChange(s.copy(perRing = Settings.PER_RING_STEPS[i + 1]))
                        }
                    },
                )

                BasicText(
                    "wygląd radaru",
                    style = HINT,
                    modifier = Modifier.padding(top = 22.dp, bottom = 2.dp),
                )
                SliderRow(
                    "wielkość strzałek", s.arrowScale, 0.5f, 2f,
                    "${(s.arrowScale * 100).roundToInt()}%",
                ) { onChange(s.copy(arrowScale = it)) }
                SliderRow(
                    "wielkość podpisów", s.textScale, 0.7f, 1.8f,
                    "${(s.textScale * 100).roundToInt()}%",
                ) { onChange(s.copy(textScale = it)) }
                SliderRow(
                    "jasność pierścieni", s.ringAlpha, 0.2f, 1f,
                    "${(s.ringAlpha * 100).roundToInt()}%",
                ) { onChange(s.copy(ringAlpha = it)) }

                BasicText(
                    "inne",
                    style = HINT,
                    modifier = Modifier.padding(top = 22.dp, bottom = 2.dp),
                )
                ToggleRow("ekran nie gaśnie", s.keepScreenOn) { onChange(s.copy(keepScreenOn = !s.keepScreenOn)) }
                BasicText(
                    "podkład mapowy i jego krycie ustawiasz w widoku mapy, kwadrat w prawym górnym rogu",
                    style = HINT,
                    modifier = Modifier.padding(top = 8.dp),
                )

                Box(Modifier.fillMaxWidth().padding(top = 34.dp, bottom = 20.dp).clickable { onClose() }) {
                    BasicText("zamknij", style = TextStyle(color = Color.White, fontSize = 16.sp))
                }
            }
        }
    }
}
