package pl.zwl.kompas

import android.Manifest
import android.content.Context
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Obszary wczytujemy raz na proces. */
object Store {
    @Volatile
    private var cached: AreaStore? = null

    fun get(ctx: Context): AreaStore =
        cached ?: synchronized(this) {
            cached ?: AreaStore.load(ctx.applicationContext).also { cached = it }
        }
}

private const val PREFS = "zwl"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ekran wybudzony przyciskiem ma wracać do aplikacji, a nie do ekranu blokady
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            )
        }
        setContent { App() }
    }
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val prefs = remember { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    var settings by remember { mutableStateOf(Settings.load(prefs)) }
    var showSettings by remember { mutableStateOf(false) }

    val store by produceState<AreaStore?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { Store.get(ctx) }
    }

    var granted by remember { mutableStateOf(hasLocationPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { granted = hasLocationPermission(ctx) }

    var loc by remember { mutableStateOf<Location?>(null) }
    var allHits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var anchor by remember { mutableStateOf<Location?>(null) }
    var heading by remember { mutableFloatStateOf(0f) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var waypoint by remember {
        mutableStateOf(
            if (prefs.contains("wpLat")) {
                LatLon(
                    java.lang.Double.longBitsToDouble(prefs.getLong("wpLat", 0)),
                    java.lang.Double.longBitsToDouble(prefs.getLong("wpLon", 0)),
                )
            } else {
                null
            },
        )
    }
    val declination = remember { mutableFloatStateOf(0f) }

    DisposableEffect(settings.keepScreenOn) {
        view.keepScreenOn = settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    LaunchedEffect(granted) {
        if (!granted) return@LaunchedEffect
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            locationFlow(ctx).collect { l ->
                loc = l
                declination.floatValue = declinationFor(l)
                now = System.currentTimeMillis()
            }
        }
    }

    LaunchedEffect(settings.headingUp) {
        if (!settings.headingUp) {
            heading = 0f
            return@LaunchedEffect
        }
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            headingFlow(ctx) { declination.floatValue }.collect { heading = it }
        }
    }

    LaunchedEffect(Unit) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) {
                now = System.currentTimeMillis()
                delay(60_000L)
            }
        }
    }

    // pełne przeliczenie po przemieszczeniu o 100 m albo po zmianie zasięgu
    LaunchedEffect(store, loc, settings.r3) {
        val s = store ?: return@LaunchedEffect
        val l = loc ?: return@LaunchedEffect
        val a = anchor
        if (a == null || a.distanceTo(l) > 100f) {
            anchor = l
            allHits = withContext(Dispatchers.Default) {
                s.nearest(l.latitude, l.longitude, settings.rangeM)
            }
        }
    }

    val rings = remember(settings.r1, settings.r2, settings.r3) { settings.ringsKm }

    val markers = remember(allHits, settings.r1, settings.r2, settings.r3, settings.perRing) {
        selectForRings(allHits, intArrayOf(settings.r1, settings.r2, settings.r3), settings.perRing)
    }

    val user = loc?.let { LatLon(it.latitude, it.longitude) }
    val wp = waypoint
    var wpDist: Float? = null
    var wpBearing: Float? = null
    if (user != null && wp != null) {
        val (d, b) = bearingDistance(user.lat, user.lon, wp.lat, wp.lon)
        wpDist = d
        wpBearing = b
    }

    Box(Modifier.fillMaxSize().background(COL_BG)) {
        RadarCanvas(
            markers = markers,
            heading = heading,
            ringsKm = rings,
            waypointBearing = wpBearing,
            modifier = Modifier.fillMaxSize(),
        )

        store?.let { s ->
            MiniMap(
                store = s,
                user = user,
                waypoint = waypoint,
                ringsKm = rings,
                tilesEnabled = settings.tiles,
                onWaypoint = { newWp ->
                    waypoint = newWp
                    val editor = prefs.edit()
                    if (newWp == null) {
                        editor.remove("wpLat").remove("wpLon")
                    } else {
                        editor.putLong("wpLat", java.lang.Double.doubleToRawLongBits(newWp.lat))
                        editor.putLong("wpLon", java.lang.Double.doubleToRawLongBits(newWp.lon))
                    }
                    editor.apply()
                },
                modifier = Modifier.align(Alignment.BottomStart).padding(14.dp),
            )
        }

        BasicText(
            text = "⚙",
            style = TextStyle(color = Color(0xCCFFFFFF), fontSize = 20.sp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(18.dp)
                .clickable { showSettings = true },
        )

        BasicText(
            text = if (settings.headingUp) "kompas" else "północ",
            style = TextStyle(color = Color(0x99FFFFFF), fontSize = 11.sp),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(18.dp)
                .clickable {
                    settings = settings.copy(headingUp = !settings.headingUp)
                    settings.save(prefs)
                },
        )

        if (wpDist != null) {
            BasicText(
                text = "cel ${formatKm(wpDist)}",
                style = TextStyle(color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
            )
        }

        val status = when {
            !granted -> "brak zgody na lokalizację"
            store == null -> "wczytywanie obszarów"
            loc == null -> "czekam na pozycję"
            now - (loc?.time ?: 0L) > 300_000L ->
                "pozycja sprzed ${((now - (loc?.time ?: 0L)) / 60000L).toInt()} min"
            markers.isEmpty() && anchor != null -> "brak obszarów w zasięgu ${settings.r3} km"
            else -> null
        }
        if (status != null) {
            BasicText(
                text = status,
                style = TextStyle(color = Color(0xB3FFFFFF), fontSize = 12.sp, textAlign = TextAlign.Center),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = if (wpDist != null) 50.dp else 24.dp)
                    .clickable {
                        if (!granted) {
                            permLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                ),
                            )
                        }
                    },
            )
        }

        if (showSettings) {
            SettingsSheet(
                s = settings,
                onChange = {
                    settings = it
                    it.save(prefs)
                },
                onClose = { showSettings = false },
            )
        }

        LaunchedEffect(Unit) {
            if (!granted) {
                permLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                    ),
                )
            }
        }
    }
}
